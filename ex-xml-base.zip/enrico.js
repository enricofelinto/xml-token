/*
let name = 'enrico';
let codifiedName = 'luypjv';

function encodify(data) {
    data = data.toLowerCase();
    
    let alphabet = 'abcdefghijklmnopqrstuvwxyz0123456789'
    alphabet = alphabet.split('');
    
    let encryptedData = []
    for(let i = 0; i < data.length; i++){
        let dataIndex = alphabet.indexOf(data[i]);
        let finalIndex1 = dataIndex + 7;
        if((finalIndex1) >= 36){
            while(finalIndex1 >= 36){
                finalIndex1 = finalIndex1 - 36;
            }
        };
        encryptedData[i] = alphabet[finalIndex1];
    }
    console.log(encryptedData.join(''));
}

//encodify(name);

function decodify(enData) {
    enData = enData.toLowerCase();
    
    let alphabet = 'abcdefghijklmnopqrstuvwxyz0123456789'
    alphabet = alphabet.split('');
    
    let encryptedData = []
    for(let i = 0; i < enData.length; i++){
        let dataIndex = alphabet.indexOf(enData[i]);
        let finalIndex2 = dataIndex - 7;
        if((finalIndex2) < 0){
            while(finalIndex2 < 0){
                finalIndex2 = finalIndex2 + 36;
            }
        };
        encryptedData[i] = alphabet[finalIndex2];
    }
    console.log(encryptedData.join(''));
}
*/
//decodify(codifiedName);






























/*


//Now we do the second part of this shit:
//sorry for the vocabulary.... :c

let info = {
    name: 'Enrico Bartholomeu Felinto',
    address: 'Rua Doutor Luiz Barreto, 253',
    phoneNumber: '+55 (11) 93800-0744'
};
let info2 = {
    name: 'zap',
    address: 'aaaa',
    phoneNumber: '(11) 99944-7485'
}

function tokenize(data){
    var nameToken = [];
    var addressToken = [];
    var phoneNumberToken = []; 
    var tokenizedInfo = {
        name: '',
        address: '',
        phoneNumber: ''
    }

    //name related testing:aind
    if(data.name != ''){
        if(data.name.split(' ').length == 1 ){
            let str = data.name
            str = str.split('')
            nameToken = str[0];
            console.log(nameToken)
            tokenizedInfo.name = nameToken.join('');

        }
        else{
            for(let i = 0; i < data.name.split(' ').length; i++){
                let str = data.name.split(' ');
                str[i] = str[i].split('')
                nameToken[i] = str[i][0];
            }
            console.log(nameToken.join(''))
            tokenizedInfo.name = nameToken.join('');
        }
    }
    else{
        console.log('\nError: You forgot to input a name!\n')
    }

    if(data.address != ''){
        if(data.address.split(' ').length == 1){
            let str = data.address
            str = str.split('')
            addressToken = str[0];
            console.log(addressToken)
            tokenizedInfo.address = addressToken.join('')
        }
        else{
            for(let i = 0; i < data.address.split(' ').length; i++){
                let str = data.address.split(' ');
                str[i] = str[i].split('')
                addressToken[i] = str[i][0];
            }
            console.log(addressToken.join(''))
            tokenizedInfo.address = addressToken.join('');
        }
    }
    else{
        console.log('\nError: You forgot to input an address!\n')
    }

    if(data.phoneNumber != ''){

    }

    console.log('\n')
    console.log(tokenizedInfo)
}

tokenize(info); 

*/



























/*







//now the actual thing we are going to try:
//first we loop the reading but we need to search how to get only some parts

//npm install fast-xml-parser

//npm init

//npm i -S fast-csv
//npm i -S @fast-csv/parse
//npm i -S @fast-csv/format

const fs = require('fs');
const csv = require('@fast-csv/parse');
const fileNameFuncs = require('./fileNames.js'); 

let files = [];
let numOfFiles = 100
let i = 1
let k = 0
obj = {}

fileNameFuncs.getFileName('C:\\Enrico\\Projects\\Encrypting data\\xmls\\xmls').then( (v) => { files = v }, null ).then(toParser, null) // change the file path

function toParser(){
    return new Promise ((res,rej) => {
        function parser() {
            obj = {}
            const currentFile = `C:\\Enrico\\Projects\\Encrypting data\\xmls\\xmls\\${files[0][k]}` // change the file path
            csv.parseFile(currentFile, {delimiter : '\t'})
            .on('error', (err) => { console.log(err) })
            .on('data', parse)
            .on('end', () => { write(files[0][k]) })
            if( k == numOfFiles){
                res()
            } else {
                setTimeout(() => {
                    parser()
                }, 100)
            }
        }
        parser()
    })
}

function parse(row){
    let tSplit = row[0].split(',')
    obj[tSplit[0]] = {
        "codigo_imovel" : tSplit[0],
        "denominacao_imovel" : tSplit[1],
        "codigo_municipio" : tSplit[2],
        "uf" : tSplit[3],
        "municipio" : tSplit[4],
        "area_total" : tSplit[5],
        "nome_titular" : tSplit[6],
        "condicao_pessoa" : tSplit[7],
        "percentual_detencao" : tSplit[8],
        "pais" : tSplit[9],
    };
    i++
}

function write(cFile){
    let string = JSON.stringify(obj)
    if(k == 0){
        fs.writeFile('./x.txt', `{"${cFile}":${string},` , function (err) {
            if(err){ console.log(err) }
         })
    } else if ( k < numOfFiles){
        fs.appendFile('./x.txt', `"${cFile}":${string},` , function (err) {
            if(err){ console.log(err) }
         })
    } else {
        fs.appendFile('./x.txt', `"${cFile}":${string}}` , function (err) {
            if(err){ console.log(err) }
         })
    }
    console.log(Math.round(process.memoryUsage().heapUsed / 1000 / 1000) + ' MB')
    k++
}

/**
 * Changes XML to JSON
 * Modified version from here: http://davidwalsh.name/convert-xml-json
 * @param {string} xml XML DOM tree
 

var fs = require('fs');
var DOMParser = require('xmldom').DOMParser;

function xmlToJson(xml) {
    // Create the return object
    var obj = {};
  
    if (xml.nodeType == 1) {
      // element
      // do attributes
      if (xml.attributes.length > 0) {
        obj["@attributes"] = {};
        for (var j = 0; j < xml.attributes.length; j++) {
          var attribute = xml.attributes.item(j);
          obj["@attributes"][attribute.nodeName] = attribute.nodeValue;
        }
      }
    } else if (xml.nodeType == 3) {
      // text
      obj = xml.nodeValue;
    }
  
    // do children
    // If all text nodes inside, get concatenated text from them.
    var textNodes = [].slice.call(xml.childNodes).filter(function(node) {
      return node.nodeType === 3;
    });
    if (xml.hasChildNodes() && xml.childNodes.length === textNodes.length) {
      obj = [].slice.call(xml.childNodes).reduce(function(text, node) {
        return text + node.nodeValue;
      }, "");
    } else if (xml.hasChildNodes()) {
      for (var i = 0; i < xml.childNodes.length; i++) {
        var item = xml.childNodes.item(i);
        var nodeName = item.nodeName;
        if (typeof obj[nodeName] == "undefined") {
          obj[nodeName] = xmlToJson(item);
        } else {
          if (typeof obj[nodeName].push == "undefined") {
            var old = obj[nodeName];
            obj[nodeName] = [];
            obj[nodeName].push(old);
          }
          obj[nodeName].push(xmlToJson(item));
        }
      }
    }
    return obj;
}

*/

const fs = require('fs');
const csv = require('@fast-csv/parse')

var folder = []

const directory = '..\\Users\\franciscofelinto\\Downloads\\Projetos_Desenvolvimento/Projeto_XML\\material_apoio\\xmls';



fs.readdirSync(directory).forEach(file => {
  console.log(file);
  folder.push(file)
});

var xmls = [];

const test = function(){
    for(let i = 0; i < folder.length; i++){
       var stream = fs.createReadStream(directory + '\\' +folder[i]);
       csv.parseStream(stream)
        .on('error', error => console.error(error))
        .on('data', row => xmls[i] = `ROW=${JSON.stringify(row)}`) 
        .on('end', rowCount => console.log(`Parsed ${rowCount} rows`));
    }
    const xmlLog = function(){
        console.log(xmls)
    }
    setTimeout(xmlLog(), 10000)
}
test()

