/*var fs = require("fs");

fs.readFile("test.xml", "utf-8", function(data, err) {
  if (err) console.log(err);
  console.log(data);
});
*/

var fs = require("fs"),
  parseString = require("xml2js").parseString;

fs.readFile("nfe-edited.xml", "utf-8", function(err, data) {
  if (err) console.log(err);
  // we log out the readFile results
  console.log(data);
  // we then pass the data to our method here
  parseString(data, function(err, result) {
    if (err) console.log(err);
    // here we log the results of our xml string conversion
    console.log(result);
  });
});